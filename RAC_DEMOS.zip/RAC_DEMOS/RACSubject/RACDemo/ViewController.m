//
//  ViewController.m
//  RACDemo
//
//  Created by admin on 2017/10/20.
//  Copyright © 2017年 AlezJi. All rights reserved.

#import "ViewController.h"
#import "NextViewController.h"
#import "ReactiveCocoa.h"


@interface ViewController ()
@property(nonatomic, copy)UIButton * button;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self buildUI];
}

- (void)buildUI {
    self.button.frame = CGRectMake(100, 100, 80, 30);
    [self.view addSubview:self.button];
    self.view.backgroundColor = [UIColor whiteColor];
}


#pragma mark--btnOnClick
- (void)btnOnClick {
    NextViewController *nextVC = [[NextViewController alloc] init];
    
    
    nextVC.subject = [RACSubject subject];
    [nextVC.subject subscribeNext:^(id x) {  // 这里的x便是sendNext发送过来的信号
        NSLog(@"%@", x);
        [self.button setTitle:x forState:UIControlStateNormal];
    }];
    
    [self.navigationController pushViewController:nextVC animated:YES];
}



#pragma mark---lazy loading
- (UIButton *)button {
    if (!_button) {
        _button = [[UIButton alloc] init];
        [_button setBackgroundColor:[UIColor redColor]];
        [_button setTitle:@"push" forState:UIControlStateNormal];
        [_button addTarget:self action:@selector(btnOnClick) forControlEvents:UIControlEventTouchUpInside];
    }
    return _button;
}

@end
