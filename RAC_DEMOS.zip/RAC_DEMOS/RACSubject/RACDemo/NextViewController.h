//
//  NextViewController.h
//  RACDemo
//
//  Created by admin on 2017/10/24.
//  Copyright © 2017年 AlezJi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ReactiveCocoa.h"

@interface NextViewController : UIViewController

@property(nonatomic, strong)RACSubject *subject;


@end
