//
//  RequestViewModel.h
//  RACDemo
//
//  Created by admin on 2017/10/24.
//  Copyright © 2017年 AlezJi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ReactiveCocoa.h"
#import "AFNetworking.h"


@interface RequestViewModel : NSObject
@property(nonatomic, strong, readonly)RACCommand *requestCommand;

@end
