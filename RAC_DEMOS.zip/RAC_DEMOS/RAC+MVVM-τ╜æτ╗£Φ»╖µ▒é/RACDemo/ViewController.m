//
//  ViewController.m
//  RACDemo
//
//  Created by admin on 2017/10/20.
//  Copyright © 2017年 AlezJi. All rights reserved.

#import "ViewController.h"
#import "ReactiveCocoa.h"
#import "RequestViewModel.h"

@interface ViewController ()
// 请求视图模型
@property(nonatomic, strong)RequestViewModel *requestVM;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // GET  https://api.douban.com/v2/book/search
    // 发送请求
    RACSignal *signal = [self.requestVM.requestCommand execute:nil];
    [signal subscribeNext:^(id x) {
        NSLog(@"-发送请求%@",x);
    }];

}


- (RequestViewModel *)requestVM {
    if (!_requestVM) {
        _requestVM = [[RequestViewModel alloc] init];
    }
    return _requestVM;
}


@end
