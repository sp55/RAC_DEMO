//
//  RequestViewModel.m
//  RACDemo
//
//  Created by admin on 2017/10/24.
//  Copyright © 2017年 AlezJi. All rights reserved.
//

#import "RequestViewModel.h"
#import "BooksModel.h"


@interface RequestViewModel()
@property(strong,nonatomic)NSMutableArray *dataArr;
@end

@implementation RequestViewModel

- (instancetype)init {
    if (self = [super init]) {
        [self setup];
    }
    return self;
}

- (void)setup {
    
    _requestCommand = [[RACCommand alloc] initWithSignalBlock:^RACSignal *(id input) {
        // 创建信号 把发送请求的代码包装到信号里面。
        RACSignal *signal = [RACSignal createSignal:^RACDisposable *(id<RACSubscriber> subscriber) {
            AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
            [manager GET:@"https://api.douban.com/v2/book/search" parameters:@{@"q":@"帅哥"} progress:^(NSProgress * _Nonnull downloadProgress) {
                
            } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                NSLog(@"%@", responseObject);

                
                [self.dataArr addObjectsFromArray:[BooksModel mj_objectArrayWithKeyValuesArray:responseObject[@"books"]]];
                
                [subscriber sendNext:@"success"];
                
                [subscriber sendCompleted];
                
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                
            }];
            return nil;
        }];
        
        return signal;
    }];
    
}




-(NSInteger)numberOfRowInSection:(NSInteger)section{
        return self.dataArr.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell1"];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    BooksModel *books = self.dataArr[indexPath.row];
    cell.textLabel.text = [NSString stringWithFormat:@"==%ld=%@",indexPath.row,books.alt_title];
    [cell.imageView sd_setImageWithURL:[NSURL URLWithString:books.image]];
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.01;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

-(NSMutableArray *)dataArr{
    if (!_dataArr) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}
@end
