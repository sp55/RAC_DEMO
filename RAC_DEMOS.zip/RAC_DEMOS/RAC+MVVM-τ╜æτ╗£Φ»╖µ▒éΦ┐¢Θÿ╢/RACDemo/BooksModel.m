//
//  BooksModel.m
//  RACDemo
//
//  Created by admin on 2017/10/24.
//  Copyright © 2017年 AlezJi. All rights reserved.
//

#import "BooksModel.h"

@implementation BooksModel


@end
