//
//  BooksModel.h
//  RACDemo
//
//  Created by admin on 2017/10/24.
//  Copyright © 2017年 AlezJi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BooksModel : NSObject
//alt = "https://book.douban.com/subject/24869019/";
//"alt_title" = "Business networking and sex";
//"author_intro" = "\U4f0a\U51e1\U00b7\U7c73\U65af\U7eb3\U535a\U58eb\Uff08Dr. Ivan Misner\Uff09\Uff0c\U4e16\U754c\U4e0a\U6700\U5927\U7684\U5546\U4e1a\U793e\U4ea4\U7ec4\U7ec7\U56fd\U9

@property(strong,nonatomic)NSString *alt;
@property(strong,nonatomic)NSString *alt_title;
@property(strong,nonatomic)NSString *author_intro;
@property(strong,nonatomic)NSString *image;


@end
